from setuptools import setup

setup(
    name='imessage-chatgpt-bot',
    version='0.1',
    py_modules=['/Users/kellygold/Desktop/imessage-chatgpt-bot/'],
    install_requires=[
        'chatgpt_wrapper',
        'imessage_tools',
    ],
)